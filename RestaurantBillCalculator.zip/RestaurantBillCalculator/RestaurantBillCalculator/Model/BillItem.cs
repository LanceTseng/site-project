﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantBillCalculator.Model
{
    internal class BillItem
    {
        public string Name { get; set; }
        public string Category { get; set; }
        public decimal Price { get; set; }
        public decimal Qty { get; set; }

        public BillItem(string name, string category, decimal price, decimal qty)
        {
            Name = name;
            Category = category;
            Price = price;
            Qty = qty;
        }
    }
}
