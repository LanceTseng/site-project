﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;

namespace RestaurantBillCalculator.Model
{
    internal class Menu
    {
        public ObservableCollection<MenuItem> Items { get; set; }

        private string _filePath = "menu.txt";

        public Menu()
        {
            Items = new ObservableCollection<MenuItem>();
            Load(_filePath);
        }

        private void Load(string _filePath)
        {
            var lines = File.ReadAllLines(_filePath);
            foreach (var line in lines)
            {
                var parts = line.Split(',');
                if (parts.Length == 3)
                {
                    var name = parts[0].Trim();
                    var category = parts[1].Trim();
                    var price = Convert.ToDecimal(parts[2].Trim());
                    Items.Add(new MenuItem(name, category, price));
                }
            }
        }
         
        public List<string> Categories()
        {
            return Items.Select(item => item.Category).Distinct().OrderBy(category => category).ToList();
        }

        public void Remove(MenuItem menuItem)
        {
            var existingItem = Items.FirstOrDefault(x => x.Name == menuItem.Name);
            if (existingItem != null)
            {
                Items.Remove(menuItem);
            }
          
        }
    }
}