﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestaurantBillCalculator.Model
{
    internal class Bill
    {
        public ObservableCollection<BillItem> BillItems { get; set; }

        private decimal _taxRate = Convert.ToDecimal(0.13);

        public Bill()
        {
            BillItems = new ObservableCollection<BillItem>();
        }

        public void AddItem(BillItem item)
        {
            var existingItem = BillItems.FirstOrDefault(x => x.Name == item.Name);
            if (existingItem != null)
            {
                // Update the quantity of the existing item
                existingItem.Qty += 1;
            }
            else
            {
                BillItems.Add(item);
            }
        }

        public void UpdateQty(BillItem item)
        {
            var existingItem = BillItems.FirstOrDefault(x => x.Name == item.Name);
            if (existingItem != null)
            {
                // Update the quantity of the existing item
                existingItem.Qty += item.Qty;
            }
            
        }
        public void RemoveItem(string itemName)
        {
            var existingItem = BillItems.FirstOrDefault(x => x.Name == itemName);
            if (existingItem != null)
            {
                BillItems.Remove(existingItem);
            }
        }

        public void ClearBill()
        {
            BillItems.Clear();
        }

        public decimal GetSubTotal()
        {
            return (BillItems.Any())? BillItems.Sum(x => x.Price * x.Qty) : 0;
        }

        public decimal GetTax()
        {
            return (BillItems.Any()) ? GetSubTotal() * _taxRate : 0;
        }

        public decimal GetTotal()
        {
            return (BillItems.Any()) ? GetSubTotal() + GetTax() : 0;
        }
    }
}
