﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using RestaurantBillCalculator.Model;
using Menu = RestaurantBillCalculator.Model.Menu;
using MenuItem = RestaurantBillCalculator.Model.MenuItem;

namespace RestaurantBillCalculator
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Menu _menu;
        private Bill _bill;

        public MainWindow()
        {
            InitializeComponent();
            _menu = new Menu();
            _bill = new Bill();
            InitializeControls();
        }

        private void InitializeControls()
        {
            SetMenuCategory();
            SetMenuItem();
            SetBill();
            SetSummaryAmount();
        }

        private void SetMenuCategory()
        {
            cbxCategory.ItemsSource = _menu.Categories();
        }

        private void SetMenuItem(string category = "")
        {
            menuDataGrid.ItemsSource = null;
            if (!string.IsNullOrEmpty(category))
                menuDataGrid.ItemsSource = _menu.Items.Where(item => item.Category == category).ToList();
            else
                menuDataGrid.ItemsSource = _menu.Items;
        }

        private void SetBill()
        {
            billDataGrid.ItemsSource = null;
            billDataGrid.ItemsSource = _bill.BillItems;
        }

        private void SetSummaryAmount()
        {
            txtSubtotal.Text = _bill.GetSubTotal().ToString("C");
            txtTax.Text = _bill.GetTax().ToString("C");
            txtTotal.Text = _bill.GetTotal().ToString("C");
        }

        private void cbxCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbxCategory.SelectedItem != null)
            {
                string selectedCategory = cbxCategory.SelectedItem.ToString();
                SetMenuItem(selectedCategory);
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            _bill.ClearBill();
            SetSummaryAmount();
        }

        private void menuDataGrid_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var clickedRow = FindVisualParent<DataGridRow>(e.OriginalSource as DependencyObject);
            if (clickedRow != null)
            {
                var menuItem = (MenuItem)clickedRow.Item;
                var billItem = new BillItem(menuItem.Name, menuItem.Category, menuItem.Price, 1);
                if (billItem != null)
                {
                    _bill.AddItem(billItem);

                    SetBill();
                    SetSummaryAmount();
                }
            }
        }

        private static T FindVisualParent<T>(DependencyObject obj) where T : DependencyObject
        {
            while (obj != null)
            {
                if (obj is T parent)
                {
                    return parent;
                }
                obj = VisualTreeHelper.GetParent(obj);
            }
            return null;
        }

        private void btnMenuRemove_Click(object sender, RoutedEventArgs e)
        {
            if (menuDataGrid.SelectedItems.Count > 0)
            {
                var menuItem = menuDataGrid.SelectedItems[0] as MenuItem;

                _menu.Remove(menuItem);

                SetMenuItem(cbxCategory.SelectedItem.ToString());

                _bill.RemoveItem(menuItem.Name);

                SetBill();
                SetSummaryAmount();
            }
        }

        private void btnBillRemove_Click(object sender, RoutedEventArgs e)
        {
            if (billDataGrid.SelectedItems.Count > 0)
            {
                var billItem = billDataGrid.SelectedItems[0] as BillItem;

                _bill.RemoveItem(billItem.Name);

                SetBill();
                SetSummaryAmount();
            }
        }

        private void billDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                var editedTextBox = e.EditingElement as TextBox;
                if (editedTextBox != null)
                {
                    string newValue = editedTextBox.Text;

                    var item = e.Row.Item as BillItem;
                    if (item != null)
                    {
                        item.Qty = Convert.ToDecimal(newValue);
                    }
                    SetSummaryAmount();
                }
            }
        }
    }
}