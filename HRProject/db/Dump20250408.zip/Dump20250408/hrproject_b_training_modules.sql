CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_training_modules`
--

DROP TABLE IF EXISTS `b_training_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_training_modules` (
  `training_module_id` int NOT NULL AUTO_INCREMENT,
  `training_module_name` varchar(255) DEFAULT NULL,
  `training_module_description` varchar(255) DEFAULT NULL,
  `training_department_id` int DEFAULT NULL COMMENT 'from object_type.department',
  `enabled` tinyint DEFAULT NULL,
  PRIMARY KEY (`training_module_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_training_modules`
--

LOCK TABLES `b_training_modules` WRITE;
/*!40000 ALTER TABLE `b_training_modules` DISABLE KEYS */;
INSERT INTO `b_training_modules` VALUES (1,'HR Policies & Compliance','Comprehensive training on HR policies and procedures.',1,1),(2,'Conflict Resolution','Techniques for handling workplace disputes effectively.',1,1),(3,'Employee Benefits & Compensation','Understanding employee benefits and salary structures.',1,1),(4,'Advanced Cybersecurity','In-depth security training for IT professionals.',2,1),(5,'Database Management','Best practices for managing SQL and NoSQL databases.',2,1),(6,'Cloud Computing Basics','Introduction to cloud services like AWS and Azure.',2,1),(7,'Network Security Essentials','Fundamentals of securing company networks.',2,1),(8,'DevOps & CI/CD Pipelines','Introduction to automation, Docker, and Kubernetes.',2,1),(9,'Time Management Skills','Strategies for improving productivity and efficiency.',3,1),(10,'Emotional Intelligence','Understanding and managing emotions at work.',3,1),(11,'Customer Interaction & Service','Techniques for handling customers professionally.',3,1),(12,'Fire Safety & Emergency Procedures','Training on workplace fire safety and emergency response.',4,1),(13,'Mental Health & Well-being','Promoting mental health awareness in the workplace.',4,1),(14,'Remote Work Best Practices','Guidelines for effective remote work and collaboration.',4,1),(15,'Workplace Harassment Awareness','Understanding and preventing workplace harassment.',4,1),(16,'Sustainable Business Practices','Eco-friendly strategies for corporate sustainability.',4,1);
/*!40000 ALTER TABLE `b_training_modules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-08 22:33:21
