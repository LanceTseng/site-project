CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_equipments`
--

DROP TABLE IF EXISTS `b_equipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_equipments` (
  `equipment_id` int NOT NULL AUTO_INCREMENT,
  `equipment_name` varchar(45) DEFAULT NULL,
  `equipment_type_id` varchar(45) DEFAULT NULL COMMENT 'from object_type.equipment_type',
  `equipment_code` varchar(45) DEFAULT NULL,
  `occupied` tinyint DEFAULT NULL,
  PRIMARY KEY (`equipment_id`),
  UNIQUE KEY `equipment_code_UNIQUE` (`equipment_code`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_equipments`
--

LOCK TABLES `b_equipments` WRITE;
/*!40000 ALTER TABLE `b_equipments` DISABLE KEYS */;
INSERT INTO `b_equipments` VALUES (1,'Dell XPS 15','1','LAP-001',0),(2,'MacBook Pro','1','LAP-002',0),(3,'HP Pavilion','2','DESK-001',0),(4,'Lenovo ThinkCentre','2','DESK-002',0),(5,'Dell UltraSharp','3','MON-001',0),(6,'LG 4K Monitor','3','MON-002',0),(7,'Projector Epson','4','OTH-001',0),(8,'Barcode Scanner','4','OTH-0020',0),(9,'test eqpt','4','JURKS-1',0),(10,'Laptop','1','Laptop123',1),(11,'Destop1','2','Destop122',0),(12,'Dell E8392 Workshop','2','DET3243-12345',0),(13,'Barbieputer','1','BARBIE007',0);
/*!40000 ALTER TABLE `b_equipments` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-08 22:33:20
