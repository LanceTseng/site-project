CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `v_user_employee`
--

DROP TABLE IF EXISTS `v_user_employee`;
/*!50001 DROP VIEW IF EXISTS `v_user_employee`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_employee` AS SELECT 
 1 AS `user_id`,
 1 AS `username`,
 1 AS `password`,
 1 AS `role_id`,
 1 AS `user_role`,
 1 AS `u_is_active`,
 1 AS `u_created_date`,
 1 AS `u_updated_date`,
 1 AS `employee_id`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `department_id`,
 1 AS `department_name`,
 1 AS `status`,
 1 AS `status_name`,
 1 AS `address`,
 1 AS `phone`,
 1 AS `onboard_date`,
 1 AS `offboard_date`,
 1 AS `e_is_active`,
 1 AS `e_created_date`,
 1 AS `e_last_updated_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_form_design`
--

DROP TABLE IF EXISTS `v_form_design`;
/*!50001 DROP VIEW IF EXISTS `v_form_design`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_form_design` AS SELECT 
 1 AS `form_id`,
 1 AS `form_name`,
 1 AS `form_type_id`,
 1 AS `form_type_name`,
 1 AS `form_question_type_id`,
 1 AS `form_question_type_name`,
 1 AS `form_question_id`,
 1 AS `form_question_display`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_child_task`
--

DROP TABLE IF EXISTS `v_user_child_task`;
/*!50001 DROP VIEW IF EXISTS `v_user_child_task`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_child_task` AS SELECT 
 1 AS `line_id`,
 1 AS `user_parenttask_id`,
 1 AS `user_id`,
 1 AS `child_task_id`,
 1 AS `ct_task_name`,
 1 AS `ct_desc`,
 1 AS `ct_status`,
 1 AS `ct_status_name`,
 1 AS `document_id`,
 1 AS `document_path`,
 1 AS `document_name`,
 1 AS `require_upload`,
 1 AS `training_module_id`,
 1 AS `training_module_dept_name`,
 1 AS `equipment_type_id`,
 1 AS `eqpt_type_name`,
 1 AS `equipment_id`,
 1 AS `eqpt_code`,
 1 AS `eqpt_name`,
 1 AS `acess_provisioning_id`,
 1 AS `interview_id`,
 1 AS `survey_id`,
 1 AS `survey_name`,
 1 AS `hand_over_id`,
 1 AS `ct_start_date`,
 1 AS `ct_end_date`,
 1 AS `created_date`,
 1 AS `last_updated_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_task`
--

DROP TABLE IF EXISTS `v_user_task`;
/*!50001 DROP VIEW IF EXISTS `v_user_task`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_task` AS SELECT 
 1 AS `head_id`,
 1 AS `user_id`,
 1 AS `user_name`,
 1 AS `parent_task_id`,
 1 AS `pt_group_id`,
 1 AS `pt_group_name`,
 1 AS `pt_name`,
 1 AS `pt_status`,
 1 AS `pt_status_name`,
 1 AS `count_child_tasks`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `line_id`,
 1 AS `child_task_id`,
 1 AS `ct_name`,
 1 AS `ct_status`,
 1 AS `ct_status_name`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `document_path`,
 1 AS `require_upload`,
 1 AS `training_module_id`,
 1 AS `training_module_dept_name`,
 1 AS `equipment_type_id`,
 1 AS `eqpt_type_name`,
 1 AS `equipment_id`,
 1 AS `eqpt_code`,
 1 AS `eqpt_name`,
 1 AS `acess_provisioning_id`,
 1 AS `interview_id`,
 1 AS `survey_id`,
 1 AS `survey_name`,
 1 AS `hand_over_id`,
 1 AS `ct_start_date`,
 1 AS `ct_end_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_access_provisioning`
--

DROP TABLE IF EXISTS `v_access_provisioning`;
/*!50001 DROP VIEW IF EXISTS `v_access_provisioning`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_access_provisioning` AS SELECT 
 1 AS `access_id`,
 1 AS `access_name`,
 1 AS `access_description`,
 1 AS `access_type_id`,
 1 AS `access_type_name`,
 1 AS `user_role_id`,
 1 AS `access_role_name`,
 1 AS `enabled`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_eqpt_occupied_his`
--

DROP TABLE IF EXISTS `v_eqpt_occupied_his`;
/*!50001 DROP VIEW IF EXISTS `v_eqpt_occupied_his`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_eqpt_occupied_his` AS SELECT 
 1 AS `id`,
 1 AS `equipment_id`,
 1 AS `equipment_name`,
 1 AS `occupied_by`,
 1 AS `occupied_by_name`,
 1 AS `occupied_date`,
 1 AS `released_date`,
 1 AS `occupied_task_id`,
 1 AS `occupied_task_name`,
 1 AS `released_task_id`,
 1 AS `released_task_name`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_parent_tasks`
--

DROP TABLE IF EXISTS `v_parent_tasks`;
/*!50001 DROP VIEW IF EXISTS `v_parent_tasks`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_parent_tasks` AS SELECT 
 1 AS `task_id`,
 1 AS `task_name`,
 1 AS `task_description`,
 1 AS `task_group_id`,
 1 AS `task_group`,
 1 AS `created_date`,
 1 AS `last_updated_date`,
 1 AS `enabled`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_tickets`
--

DROP TABLE IF EXISTS `v_tickets`;
/*!50001 DROP VIEW IF EXISTS `v_tickets`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_tickets` AS SELECT 
 1 AS `ticket_id`,
 1 AS `ticket_topic`,
 1 AS `ticket_description`,
 1 AS `ticket_department_id`,
 1 AS `department_name`,
 1 AS `ticket_status_id`,
 1 AS `ticket_status_name`,
 1 AS `ticket_request_date`,
 1 AS `ticket_request_by_id`,
 1 AS `ticket_request_by_name`,
 1 AS `ticket_last_updated_date`,
 1 AS `response_id`,
 1 AS `response_text`,
 1 AS `response_by_id`,
 1 AS `response_by_name`,
 1 AS `response_date`,
 1 AS `response_order`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_training_modules`
--

DROP TABLE IF EXISTS `v_training_modules`;
/*!50001 DROP VIEW IF EXISTS `v_training_modules`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_training_modules` AS SELECT 
 1 AS `training_module_id`,
 1 AS `training_module_name`,
 1 AS `training_module_description`,
 1 AS `training_department_id`,
 1 AS `training_department_name`,
 1 AS `enabled`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_employees`
--

DROP TABLE IF EXISTS `v_employees`;
/*!50001 DROP VIEW IF EXISTS `v_employees`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_employees` AS SELECT 
 1 AS `employee_id`,
 1 AS `first_name`,
 1 AS `last_name`,
 1 AS `department_id`,
 1 AS `department_name`,
 1 AS `status`,
 1 AS `status_name`,
 1 AS `address`,
 1 AS `phone`,
 1 AS `is_active`,
 1 AS `created_date`,
 1 AS `last_updated_date`,
 1 AS `link_user_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_parent_task`
--

DROP TABLE IF EXISTS `v_user_parent_task`;
/*!50001 DROP VIEW IF EXISTS `v_user_parent_task`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_parent_task` AS SELECT 
 1 AS `head_id`,
 1 AS `user_id`,
 1 AS `user_name`,
 1 AS `parent_task_id`,
 1 AS `task_group_id`,
 1 AS `task_group_name`,
 1 AS `pt_name`,
 1 AS `pt_desc`,
 1 AS `pt_status`,
 1 AS `pt_status_name`,
 1 AS `processing_rate`,
 1 AS `count_child_tasks`,
 1 AS `pt_start_date`,
 1 AS `pt_end_date`,
 1 AS `created_date`,
 1 AS `last_updated_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_form`
--

DROP TABLE IF EXISTS `v_user_form`;
/*!50001 DROP VIEW IF EXISTS `v_user_form`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_form` AS SELECT 
 1 AS `id`,
 1 AS `form_type_id`,
 1 AS `form_type_name`,
 1 AS `form_id`,
 1 AS `form_name`,
 1 AS `form_question_id`,
 1 AS `question_display`,
 1 AS `question_type_id`,
 1 AS `ques_type_name`,
 1 AS `question_response`,
 1 AS `user_childtask_id`,
 1 AS `form_created_date`,
 1 AS `form_updated_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_equipment`
--

DROP TABLE IF EXISTS `v_equipment`;
/*!50001 DROP VIEW IF EXISTS `v_equipment`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_equipment` AS SELECT 
 1 AS `equipment_id`,
 1 AS `equipment_name`,
 1 AS `equipment_type_id`,
 1 AS `equipment_type`,
 1 AS `equipment_code`,
 1 AS `occupied_by`,
 1 AS `occupied_by_name`,
 1 AS `occupied`,
 1 AS `last_update_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_payment`
--

DROP TABLE IF EXISTS `v_user_payment`;
/*!50001 DROP VIEW IF EXISTS `v_user_payment`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_payment` AS SELECT 
 1 AS `payment_id`,
 1 AS `user_id`,
 1 AS `employee_username`,
 1 AS `employee_first_name`,
 1 AS `employee_last_name`,
 1 AS `department_id`,
 1 AS `department_name`,
 1 AS `employee_status`,
 1 AS `employee_status_name`,
 1 AS `payment_type_id`,
 1 AS `payment_type_name`,
 1 AS `annual_salary`,
 1 AS `weekly_work_hours`,
 1 AS `termination_pay`,
 1 AS `created_at`,
 1 AS `updated_at`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_training`
--

DROP TABLE IF EXISTS `v_user_training`;
/*!50001 DROP VIEW IF EXISTS `v_user_training`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_training` AS SELECT 
 1 AS `id`,
 1 AS `user_id`,
 1 AS `user_name`,
 1 AS `training_module_id`,
 1 AS `training_module_name`,
 1 AS `training_module_description`,
 1 AS `training_department_id`,
 1 AS `training_department`,
 1 AS `status`,
 1 AS `training_status`,
 1 AS `verified_by`,
 1 AS `verified_name`,
 1 AS `user_ct_line_id`,
 1 AS `task_name`,
 1 AS `start_date`,
 1 AS `end_date`,
 1 AS `created_date`,
 1 AS `updated_date`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_user_access`
--

DROP TABLE IF EXISTS `v_user_access`;
/*!50001 DROP VIEW IF EXISTS `v_user_access`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_user_access` AS SELECT 
 1 AS `user_id`,
 1 AS `user_name`,
 1 AS `access_id`,
 1 AS `access_name`,
 1 AS `access_type_id`,
 1 AS `access_type_name`,
 1 AS `enabled`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `v_child_tasks`
--

DROP TABLE IF EXISTS `v_child_tasks`;
/*!50001 DROP VIEW IF EXISTS `v_child_tasks`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_child_tasks` AS SELECT 
 1 AS `child_task_id`,
 1 AS `parent_task_id`,
 1 AS `child_task_name`,
 1 AS `child_task_description`,
 1 AS `document_id`,
 1 AS `document_name`,
 1 AS `require_upload`,
 1 AS `training_module_id`,
 1 AS `training_module_dept_name`,
 1 AS `equipment_type_id`,
 1 AS `eqpt_type`,
 1 AS `access_provisioning_id`,
 1 AS `interview_id`,
 1 AS `survey_id`,
 1 AS `servey_name`,
 1 AS `hand_over_id`,
 1 AS `enabled`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `v_user_employee`
--

/*!50001 DROP VIEW IF EXISTS `v_user_employee`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_employee` AS select `b_users`.`user_id` AS `user_id`,`b_users`.`username` AS `username`,`b_users`.`password` AS `password`,`b_users`.`role_id` AS `role_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('user_role',`b_users`.`role_id`) AS `user_role`,`b_users`.`is_active` AS `u_is_active`,`b_users`.`created_date` AS `u_created_date`,`b_users`.`last_updated_date` AS `u_updated_date`,`b_employees`.`employee_id` AS `employee_id`,`b_employees`.`first_name` AS `first_name`,`b_employees`.`last_name` AS `last_name`,`b_employees`.`department_id` AS `department_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('department',`b_employees`.`department_id`) AS `department_name`,`b_employees`.`status` AS `status`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('employee_status',`b_employees`.`status`) AS `status_name`,`b_employees`.`address` AS `address`,`b_employees`.`phone` AS `phone`,`b_employees`.`onboard_date` AS `onboard_date`,`b_employees`.`offboard_date` AS `offboard_date`,`b_employees`.`is_active` AS `e_is_active`,`b_employees`.`created_date` AS `e_created_date`,`b_employees`.`last_updated_date` AS `e_last_updated_date` from (`b_users` left join `b_employees` on((`b_users`.`user_id` = `b_employees`.`link_user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_form_design`
--

/*!50001 DROP VIEW IF EXISTS `v_form_design`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_form_design` AS select `b_form_design`.`form_id` AS `form_id`,`b_form_design`.`form_name` AS `form_name`,`b_form_design`.`form_type_id` AS `form_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('form_type',`b_form_design`.`form_type_id`) AS `form_type_name`,`b_form_design`.`form_question_type_id` AS `form_question_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('form_ques_type',`b_form_design`.`form_question_type_id`) AS `form_question_type_name`,`b_form_design`.`form_question_id` AS `form_question_id`,`b_form_design`.`form_question_display` AS `form_question_display` from `b_form_design` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_child_task`
--

/*!50001 DROP VIEW IF EXISTS `v_user_child_task`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_child_task` AS select `rel_user_childtask`.`id` AS `line_id`,`rel_user_childtask`.`user_parenttask_id` AS `user_parenttask_id`,`GET_USER_TASK_USER_ID_BY_ID_FN`(`rel_user_childtask`.`user_parenttask_id`) AS `user_id`,`rel_user_childtask`.`child_task_id` AS `child_task_id`,`GET_CHILD_TASK_NAME_FN`(`rel_user_childtask`.`child_task_id`) AS `ct_task_name`,`GET_CHILD_TASK_DESC_FN`(`rel_user_childtask`.`child_task_id`) AS `ct_desc`,`rel_user_childtask`.`status` AS `ct_status`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('user_child_taks_status',`rel_user_childtask`.`status`) AS `ct_status_name`,`rel_user_childtask`.`document_id` AS `document_id`,`rel_user_childtask`.`document_path` AS `document_path`,`GET_DOCUMENT_NAME_FN`(`rel_user_childtask`.`document_id`) AS `document_name`,`rel_user_childtask`.`require_upload` AS `require_upload`,`rel_user_childtask`.`training_module_id` AS `training_module_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('training_department',`rel_user_childtask`.`training_module_id`) AS `training_module_dept_name`,`rel_user_childtask`.`equipment_type_id` AS `equipment_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('equipment_type',`rel_user_childtask`.`equipment_type_id`) AS `eqpt_type_name`,`rel_user_childtask`.`equipment_id` AS `equipment_id`,`GET_EQUIPMENT_CODE_FN`(`rel_user_childtask`.`equipment_id`) AS `eqpt_code`,`GET_EQUIPMENT_NAME_FN`(`rel_user_childtask`.`equipment_id`) AS `eqpt_name`,`rel_user_childtask`.`acess_provisioning_id` AS `acess_provisioning_id`,`rel_user_childtask`.`interview_id` AS `interview_id`,`rel_user_childtask`.`survey_id` AS `survey_id`,`GET_FORM_NAME_FN`(`rel_user_childtask`.`survey_id`) AS `survey_name`,`rel_user_childtask`.`hand_over_id` AS `hand_over_id`,`rel_user_childtask`.`start_date` AS `ct_start_date`,`rel_user_childtask`.`end_date` AS `ct_end_date`,`rel_user_childtask`.`created_date` AS `created_date`,`rel_user_childtask`.`last_updated_date` AS `last_updated_date` from `rel_user_childtask` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_task`
--

/*!50001 DROP VIEW IF EXISTS `v_user_task`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_task` AS select `v_user_parent_task`.`head_id` AS `head_id`,`v_user_parent_task`.`user_id` AS `user_id`,`v_user_parent_task`.`user_name` AS `user_name`,`v_user_parent_task`.`parent_task_id` AS `parent_task_id`,`v_user_parent_task`.`task_group_id` AS `pt_group_id`,`v_user_parent_task`.`task_group_name` AS `pt_group_name`,`v_user_parent_task`.`pt_name` AS `pt_name`,`v_user_parent_task`.`pt_status` AS `pt_status`,`v_user_parent_task`.`pt_status_name` AS `pt_status_name`,`v_user_parent_task`.`count_child_tasks` AS `count_child_tasks`,`v_user_parent_task`.`pt_start_date` AS `start_date`,`v_user_parent_task`.`pt_end_date` AS `end_date`,`v_user_child_task`.`line_id` AS `line_id`,`v_user_child_task`.`child_task_id` AS `child_task_id`,`v_user_child_task`.`ct_task_name` AS `ct_name`,`v_user_child_task`.`ct_status` AS `ct_status`,`v_user_child_task`.`ct_status_name` AS `ct_status_name`,`v_user_child_task`.`document_id` AS `document_id`,`v_user_child_task`.`document_name` AS `document_name`,`v_user_child_task`.`document_path` AS `document_path`,`v_user_child_task`.`require_upload` AS `require_upload`,`v_user_child_task`.`training_module_id` AS `training_module_id`,`v_user_child_task`.`training_module_dept_name` AS `training_module_dept_name`,`v_user_child_task`.`equipment_type_id` AS `equipment_type_id`,`v_user_child_task`.`eqpt_type_name` AS `eqpt_type_name`,`v_user_child_task`.`equipment_id` AS `equipment_id`,`v_user_child_task`.`eqpt_code` AS `eqpt_code`,`v_user_child_task`.`eqpt_name` AS `eqpt_name`,`v_user_child_task`.`acess_provisioning_id` AS `acess_provisioning_id`,`v_user_child_task`.`interview_id` AS `interview_id`,`v_user_child_task`.`survey_id` AS `survey_id`,`v_user_child_task`.`survey_name` AS `survey_name`,`v_user_child_task`.`hand_over_id` AS `hand_over_id`,`v_user_child_task`.`ct_start_date` AS `ct_start_date`,`v_user_child_task`.`ct_end_date` AS `ct_end_date` from (`v_user_parent_task` left join `v_user_child_task` on((`v_user_parent_task`.`head_id` = `v_user_child_task`.`user_parenttask_id`))) order by `v_user_parent_task`.`user_name`,`v_user_parent_task`.`pt_name`,`v_user_child_task`.`ct_task_name`,`v_user_parent_task`.`created_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_access_provisioning`
--

/*!50001 DROP VIEW IF EXISTS `v_access_provisioning`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_access_provisioning` AS select `b_access_provisioning`.`access_id` AS `access_id`,`b_access_provisioning`.`access_name` AS `access_name`,`b_access_provisioning`.`access_description` AS `access_description`,`b_access_provisioning`.`access_type_id` AS `access_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('access_type',`b_access_provisioning`.`access_type_id`) AS `access_type_name`,`b_access_provisioning`.`access_role_id` AS `user_role_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('user_role',`b_access_provisioning`.`access_role_id`) AS `access_role_name`,`b_access_provisioning`.`enabled` AS `enabled` from `b_access_provisioning` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_eqpt_occupied_his`
--

/*!50001 DROP VIEW IF EXISTS `v_eqpt_occupied_his`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_eqpt_occupied_his` AS select `h`.`id` AS `id`,`h`.`equipment_id` AS `equipment_id`,`GET_EQUIPMENT_NAME_FN`(`h`.`equipment_id`) AS `equipment_name`,`h`.`occupied_by` AS `occupied_by`,`GET_USER_NAME_FN`(`h`.`occupied_by`) AS `occupied_by_name`,`h`.`occupied_date` AS `occupied_date`,`h`.`released_date` AS `released_date`,`h`.`occupied_task_id` AS `occupied_task_id`,`GET_TASK_NAME_BY_LINE_FN`(`h`.`occupied_task_id`) AS `occupied_task_name`,`h`.`released_task_id` AS `released_task_id`,`GET_TASK_NAME_BY_LINE_FN`(`h`.`released_task_id`) AS `released_task_name` from `b_eqpt_occupied_his` `h` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_parent_tasks`
--

/*!50001 DROP VIEW IF EXISTS `v_parent_tasks`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_parent_tasks` AS select `b_parent_tasks`.`task_id` AS `task_id`,`b_parent_tasks`.`task_name` AS `task_name`,`b_parent_tasks`.`task_description` AS `task_description`,`b_parent_tasks`.`task_group_id` AS `task_group_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('task_group',`b_parent_tasks`.`task_group_id`) AS `task_group`,`b_parent_tasks`.`created_date` AS `created_date`,`b_parent_tasks`.`last_updated_date` AS `last_updated_date`,`b_parent_tasks`.`enabled` AS `enabled` from `b_parent_tasks` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_tickets`
--

/*!50001 DROP VIEW IF EXISTS `v_tickets`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_tickets` AS select `b_ticket_head`.`id` AS `ticket_id`,`b_ticket_head`.`ticket_topic` AS `ticket_topic`,`b_ticket_head`.`description` AS `ticket_description`,`b_ticket_head`.`ticket_department_id` AS `ticket_department_id`,`get_object_type_item_value_fn`('department',`b_ticket_head`.`ticket_department_id`) AS `department_name`,`b_ticket_head`.`status` AS `ticket_status_id`,`get_object_type_item_value_fn`('ticket_status',`b_ticket_head`.`status`) AS `ticket_status_name`,`b_ticket_head`.`created_date` AS `ticket_request_date`,`b_ticket_head`.`created_by` AS `ticket_request_by_id`,`get_user_name_fn`(`b_ticket_head`.`created_by`) AS `ticket_request_by_name`,`b_ticket_head`.`last_updated_date` AS `ticket_last_updated_date`,`b_ticket_detail`.`id` AS `response_id`,`b_ticket_detail`.`response` AS `response_text`,`b_ticket_detail`.`created_by` AS `response_by_id`,`get_user_name_fn`(`b_ticket_detail`.`created_by`) AS `response_by_name`,`b_ticket_detail`.`created_date` AS `response_date`,`b_ticket_detail`.`reponse_order` AS `response_order` from (`b_ticket_head` left join `b_ticket_detail` on((`b_ticket_head`.`id` = `b_ticket_detail`.`ticket_head_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_training_modules`
--

/*!50001 DROP VIEW IF EXISTS `v_training_modules`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_training_modules` AS select `b_training_modules`.`training_module_id` AS `training_module_id`,`b_training_modules`.`training_module_name` AS `training_module_name`,`b_training_modules`.`training_module_description` AS `training_module_description`,`b_training_modules`.`training_department_id` AS `training_department_id`,`get_object_type_item_value_fn`('training_department',`b_training_modules`.`training_department_id`) AS `training_department_name`,`b_training_modules`.`enabled` AS `enabled` from `b_training_modules` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_employees`
--

/*!50001 DROP VIEW IF EXISTS `v_employees`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_employees` AS select `b`.`employee_id` AS `employee_id`,`b`.`first_name` AS `first_name`,`b`.`last_name` AS `last_name`,`b`.`department_id` AS `department_id`,`get_object_type_item_value_fn`('department',`b`.`department_id`) AS `department_name`,`b`.`status` AS `status`,`get_object_type_item_value_fn`('employee_status',`b`.`status`) AS `status_name`,`b`.`address` AS `address`,`b`.`phone` AS `phone`,`b`.`is_active` AS `is_active`,`b`.`created_date` AS `created_date`,`b`.`last_updated_date` AS `last_updated_date`,`b`.`link_user_id` AS `link_user_id` from `b_employees` `b` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_parent_task`
--

/*!50001 DROP VIEW IF EXISTS `v_user_parent_task`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_parent_task` AS select `rel_user_parenttask`.`id` AS `head_id`,`rel_user_parenttask`.`user_id` AS `user_id`,`GET_USER_NAME_FN`(`rel_user_parenttask`.`user_id`) AS `user_name`,`rel_user_parenttask`.`parent_task_id` AS `parent_task_id`,`GET_TASK_GROUP_ID_FN`(`rel_user_parenttask`.`parent_task_id`) AS `task_group_id`,`GET_TASK_GROUP_NAME_FN`(`rel_user_parenttask`.`parent_task_id`) AS `task_group_name`,`GET_PARENT_TASK_NAME_FN`(`rel_user_parenttask`.`parent_task_id`) AS `pt_name`,`GET_PARENT_TASK_DESC_FN`(`rel_user_parenttask`.`parent_task_id`) AS `pt_desc`,`rel_user_parenttask`.`status` AS `pt_status`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('user_parent_taks_status',`rel_user_parenttask`.`status`) AS `pt_status_name`,`GET_PROCESSING_RATE_FN`(`rel_user_parenttask`.`id`) AS `processing_rate`,`rel_user_parenttask`.`count_child_tasks` AS `count_child_tasks`,`rel_user_parenttask`.`start_date` AS `pt_start_date`,`rel_user_parenttask`.`end_date` AS `pt_end_date`,`rel_user_parenttask`.`created_date` AS `created_date`,`rel_user_parenttask`.`last_updated_date` AS `last_updated_date` from `rel_user_parenttask` order by `rel_user_parenttask`.`user_id`,`rel_user_parenttask`.`created_date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_form`
--

/*!50001 DROP VIEW IF EXISTS `v_user_form`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_form` AS select `rel_user_form`.`id` AS `id`,`b_form_design`.`form_type_id` AS `form_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('form_ques_type',`b_form_design`.`form_type_id`) AS `form_type_name`,`rel_user_form`.`form_id` AS `form_id`,`b_form_design`.`form_name` AS `form_name`,`rel_user_form`.`form_question_id` AS `form_question_id`,`b_form_design`.`form_question_display` AS `question_display`,`b_form_design`.`form_question_type_id` AS `question_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('form_ques_type',`b_form_design`.`form_question_type_id`) AS `ques_type_name`,`rel_user_form`.`form_question_response` AS `question_response`,`rel_user_form`.`user_childtask_id` AS `user_childtask_id`,`rel_user_form`.`created_date` AS `form_created_date`,`rel_user_form`.`last_updated_date` AS `form_updated_date` from (`rel_user_form` left join `b_form_design` on((`rel_user_form`.`form_question_id` = `b_form_design`.`form_question_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_equipment`
--

/*!50001 DROP VIEW IF EXISTS `v_equipment`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_equipment` AS select `b_equipments`.`equipment_id` AS `equipment_id`,`b_equipments`.`equipment_name` AS `equipment_name`,`b_equipments`.`equipment_type_id` AS `equipment_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('equipment_type',`b_equipments`.`equipment_type_id`) AS `equipment_type`,`b_equipments`.`equipment_code` AS `equipment_code`,`GET_LATEST_OCCUPIED_BY_FN`(`b_equipments`.`equipment_id`) AS `occupied_by`,`GET_USER_NAME_FN`(`GET_LATEST_OCCUPIED_BY_FN`(`b_equipments`.`equipment_id`)) AS `occupied_by_name`,`b_equipments`.`occupied` AS `occupied`,(select coalesce(`h`.`released_date`,`h`.`occupied_date`) from `b_eqpt_occupied_his` `h` where (`h`.`equipment_id` = `b_equipments`.`equipment_id`) order by (case when (`h`.`released_date` is null) then 1 else 0 end),`h`.`released_date` desc,`h`.`occupied_date` desc limit 1) AS `last_update_date` from `b_equipments` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_payment`
--

/*!50001 DROP VIEW IF EXISTS `v_user_payment`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_payment` AS select `bup`.`id` AS `payment_id`,`vue`.`user_id` AS `user_id`,`vue`.`username` AS `employee_username`,`vue`.`first_name` AS `employee_first_name`,`vue`.`last_name` AS `employee_last_name`,`vue`.`department_id` AS `department_id`,`vue`.`department_name` AS `department_name`,`vue`.`status` AS `employee_status`,`vue`.`status_name` AS `employee_status_name`,`bup`.`payment_type_id` AS `payment_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('payment_type',`bup`.`payment_type_id`) AS `payment_type_name`,`bup`.`annual_pay` AS `annual_salary`,`bup`.`work_hours_per_week` AS `weekly_work_hours`,`bup`.`terminal_pay` AS `termination_pay`,`bup`.`created_date` AS `created_at`,`bup`.`last_updated_date` AS `updated_at` from (`v_user_employee` `vue` left join `rel_user_payment` `bup` on((`bup`.`user_id` = `vue`.`user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_training`
--

/*!50001 DROP VIEW IF EXISTS `v_user_training`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_training` AS select `rel_user_training`.`id` AS `id`,`rel_user_training`.`user_id` AS `user_id`,`GET_USER_NAME_FN`(`rel_user_training`.`user_id`) AS `user_name`,`rel_user_training`.`training_module_id` AS `training_module_id`,`b_training_modules`.`training_module_name` AS `training_module_name`,`b_training_modules`.`training_module_description` AS `training_module_description`,`b_training_modules`.`training_department_id` AS `training_department_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('training_department',`b_training_modules`.`training_department_id`) AS `training_department`,`rel_user_training`.`status` AS `status`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('training_status',`rel_user_training`.`status`) AS `training_status`,`rel_user_training`.`verified_by` AS `verified_by`,`GET_USER_NAME_FN`(`rel_user_training`.`verified_by`) AS `verified_name`,`rel_user_training`.`link_user_childtask_id` AS `user_ct_line_id`,`GET_TASK_NAME_BY_LINE_FN`(`rel_user_training`.`link_user_childtask_id`) AS `task_name`,`rel_user_training`.`start_date` AS `start_date`,`rel_user_training`.`end_date` AS `end_date`,`rel_user_training`.`created_date` AS `created_date`,`rel_user_training`.`updated_date` AS `updated_date` from (`rel_user_training` left join `b_training_modules` on((`rel_user_training`.`training_module_id` = `b_training_modules`.`training_module_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_user_access`
--

/*!50001 DROP VIEW IF EXISTS `v_user_access`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_user_access` AS select `ua`.`user_id` AS `user_id`,`GET_USER_NAME_FN`(`ua`.`user_id`) AS `user_name`,`ua`.`access_id` AS `access_id`,`a`.`access_name` AS `access_name`,`a`.`access_type_id` AS `access_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('access_type',`a`.`access_type_id`) AS `access_type_name`,`ua`.`enabled` AS `enabled` from (`rel_user_access` `ua` left join `b_access_provisioning` `a` on((`a`.`access_id` = `ua`.`access_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_child_tasks`
--

/*!50001 DROP VIEW IF EXISTS `v_child_tasks`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`lance`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `v_child_tasks` AS select `c`.`child_task_id` AS `child_task_id`,`c`.`parent_task_id` AS `parent_task_id`,`c`.`child_task_name` AS `child_task_name`,`c`.`child_task_description` AS `child_task_description`,`c`.`document_id` AS `document_id`,`d`.`document_name` AS `document_name`,`d`.`require_upload` AS `require_upload`,`c`.`training_module_id` AS `training_module_id`,`get_object_type_item_value_fn`('training_department',`c`.`training_module_id`) AS `training_module_dept_name`,`c`.`equipment_type_id` AS `equipment_type_id`,`GET_OBJECT_TYPE_ITEM_VALUE_FN`('equipment_type',`c`.`equipment_type_id`) AS `eqpt_type`,`c`.`access_provisioning_id` AS `access_provisioning_id`,`c`.`interview_id` AS `interview_id`,`c`.`survey_id` AS `survey_id`,`GET_FORM_NAME_FN`(`c`.`survey_id`) AS `servey_name`,`c`.`hand_over_id` AS `hand_over_id`,`c`.`enabled` AS `enabled` from (`b_child_tasks` `c` left join `b_documents` `d` on((`d`.`document_id` = `c`.`document_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping routines for database 'hrproject'
--
/*!50003 DROP FUNCTION IF EXISTS `get_child_task_desc_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_child_task_desc_fn`(p_task_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_task_desc VARCHAR(255);

    SELECT child_task_description INTO lv_task_desc 
    FROM b_child_tasks 
    WHERE child_task_id = p_task_id;

    RETURN lv_task_desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_child_task_name_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_child_task_name_fn`(p_task_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_task_name VARCHAR(255);

    SELECT child_task_name INTO lv_task_name 
    FROM b_child_tasks 
    WHERE child_task_id = p_task_id;

    RETURN lv_task_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `GET_DOCUMENT_NAME_FN` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `GET_DOCUMENT_NAME_FN`(p_doc_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_doc_name VARCHAR(255);
    
    -- Retrieve document name
    SELECT document_name INTO lv_doc_name 
    FROM b_documents 
    WHERE document_id = p_doc_id 
    LIMIT 1;
    
    RETURN lv_doc_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_doument_name_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_doument_name_fn`(p_doc_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_doc_name VARCHAR(255);
    
    -- Retrieve document name
    SELECT document_name INTO lv_doc_name 
    FROM b_documents 
    WHERE document_id = p_doc_id 
    LIMIT 1;
    
    RETURN lv_doc_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_equipment_code_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_equipment_code_fn`(p_eqpt_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_eqpt_code VARCHAR(255);

    SELECT equipment_code 
    INTO lv_eqpt_code 
    FROM b_equipments 
    WHERE equipment_id = p_eqpt_id 
    LIMIT 1;

    RETURN lv_eqpt_code;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_equipment_name_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_equipment_name_fn`(p_eid INT) RETURNS varchar(45) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_eqpt_name VARCHAR(45);

    -- Fetch equipment name based on equipment ID
    SELECT e.equipment_name 
    INTO lv_eqpt_name 
    FROM b_equipments e 
    WHERE e.equipment_id = p_eid
    LIMIT 1;

    -- Return the equipment name (or empty string if NULL)
    RETURN COALESCE(lv_eqpt_name, '');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_form_name_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_form_name_fn`(p_form_id INT) RETURNS varchar(100) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_form_name VARCHAR(100);
    
    SELECT f.form_name 
    INTO lv_form_name
    FROM b_form_design f 
    WHERE f.form_id = p_form_id 
    LIMIT 1;

    RETURN lv_form_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_latest_occupied_by_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_latest_occupied_by_fn`(p_eqpt_id INT) RETURNS int
    DETERMINISTIC
BEGIN
    DECLARE ln_occupied_by INT;
SELECT 
    COALESCE(CAST(h.occupied_by AS CHAR), '')
INTO ln_occupied_by FROM
    b_eqpt_occupied_his h
WHERE
    h.equipment_id = p_eqpt_id
        AND h.released_date IS NULL
ORDER BY h.occupied_date DESC
LIMIT 1;
    RETURN ln_occupied_by;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_object_type_item_value_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_object_type_item_value_fn`(
    p_object_type_name VARCHAR(255),
    p_object_type_item_key INT
) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE result_value VARCHAR(255);

    SELECT object_type_item_value 
    INTO result_value 
    FROM b_object_type 
    WHERE object_type_name = p_object_type_name 
      AND object_type_item_key = p_object_type_item_key
    LIMIT 1;  -- Ensure only one result is returned

    RETURN result_value;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_parent_task_desc_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_parent_task_desc_fn`(p_task_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_task_desc VARCHAR(255);

    SELECT task_description INTO lv_task_desc 
    FROM b_parent_tasks 
    WHERE task_id = p_task_id;

    RETURN lv_task_desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_parent_task_name_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_parent_task_name_fn`(p_task_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_task_name VARCHAR(255);

    SELECT task_name INTO lv_task_name 
    FROM b_parent_tasks 
    WHERE task_id = p_task_id;

    RETURN lv_task_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_processing_rate_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_processing_rate_fn`(p_parent_task_id INT) RETURNS decimal(10,2)
    DETERMINISTIC
BEGIN
    DECLARE ln_ct_total INT;
    DECLARE ln_ct_done INT;
    DECLARE ln_ct_rate DECIMAL(10,2);
    
    -- Get total count of child tasks
SELECT 
    COUNT(1)
INTO ln_ct_total FROM
    v_user_child_task ct
WHERE
    ct.user_parenttask_id = p_parent_task_id;
    
    -- Get count of completed child tasks
SELECT 
    COUNT(1)
INTO ln_ct_done FROM
    v_user_child_task ct
WHERE
    ct.user_parenttask_id = p_parent_task_id
        AND ct.ct_status_name = 'completed';
    
    -- Calculate completion percentage
    IF ln_ct_total > 0 THEN
        SET ln_ct_rate = (ln_ct_done / ln_ct_total) * 100;
    ELSE
        -- here
          -- Get total count of child tasks
    SELECT COUNT(1) INTO ln_ct_total 
    FROM rel_user_parenttask ct 
    WHERE ct.id = p_parent_task_id;
    
    -- Get count of completed child tasks
SELECT 
    COUNT(1)
INTO ln_ct_done FROM
    rel_user_parenttask ct
WHERE
    ct.id = p_parent_task_id
        AND ct.status = 2;
        SET ln_ct_rate = (ln_ct_done / ln_ct_total) * 100;
    END IF;
    
    RETURN ln_ct_rate;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_task_group_id_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_task_group_id_fn`(p_task_id INT) RETURNS int
    READS SQL DATA
    DETERMINISTIC
BEGIN
    DECLARE p_group_id INT DEFAULT -1;

    SELECT IFNULL(task_group_id, -1)
    INTO p_group_id
    FROM b_parent_tasks 
    WHERE task_id = p_task_id
    LIMIT 1;

    RETURN p_group_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_task_group_name_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_task_group_name_fn`(p_task_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE p_group_name VARCHAR(255);

    SELECT get_object_type_item_value_fn('task_group', task_group_id) 
    INTO p_group_name 
    FROM b_parent_tasks 
    WHERE task_id = p_task_id;

    RETURN p_group_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_task_name_by_line_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_task_name_by_line_fn`(p_line_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_task_name VARCHAR(255);

    -- Fetch the task name based on line_id
    SELECT v.ct_name 
    INTO lv_task_name 
    FROM v_user_task v 
    WHERE v.line_id = p_line_id
    ORDER BY v.ct_name DESC 
    LIMIT 1;

    -- Return the task name (or empty string if NULL)
    RETURN COALESCE(lv_task_name, '');
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_user_name_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_user_name_fn`(p_user_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE lv_user_name VARCHAR(255);

    SELECT username INTO lv_user_name 
    FROM b_users 
    WHERE user_id = p_user_id;

    RETURN lv_user_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_user_task_user_id_by_id_fn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` FUNCTION `get_user_task_user_id_by_id_fn`(p_head_id INT) RETURNS varchar(255) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
    DECLARE ln_user_id VARCHAR(255);

    SELECT user_id INTO ln_user_id 
    FROM v_user_parent_task 
    WHERE head_id = p_head_id 
    LIMIT 1;

    RETURN ln_user_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `revert_deleted_user` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` PROCEDURE `revert_deleted_user`(IN p_uid INT)
BEGIN
    -- Check if user exists in backup
    IF (SELECT COUNT(*) FROM b_users WHERE user_id = p_uid) > 0 THEN

        -- Remove from Backup After Restore
        DELETE FROM b_employees WHERE link_user_id = p_uid;
        DELETE FROM b_users WHERE user_id = p_uid;

        SELECT 'User restored successfully' AS message;
    ELSE
        SELECT 'No backup found for this user' AS message;
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `revert_user_task` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` PROCEDURE `revert_user_task`(
    IN p_user_id INT, 
    OUT lv_result VARCHAR(20)
)
BEGIN
    DECLARE ln_c_count INT DEFAULT 0;
    DECLARE ln_p_count INT DEFAULT 0;

    -- Delete child tasks related to user's parent tasks
DELETE FROM rel_user_childtask 
WHERE
    EXISTS( SELECT 
        *
    FROM
        rel_user_parenttask
    
    WHERE
        user_id = p_user_id
        AND id = user_parenttask_id);

    -- Delete parent tasks
DELETE FROM rel_user_parenttask 
WHERE
    user_id = p_user_id;

    -- Check remaining tasks
SELECT 
    COUNT(1)
FROM
    rel_user_childtask
WHERE
    EXISTS( SELECT 
            *
        FROM
            rel_user_parenttask
        WHERE
            user_id = p_user_id
                AND id = user_parenttask_id);
SELECT 
    COUNT(1)
INTO ln_p_count FROM
    rel_user_parenttask
WHERE
    user_id = p_user_id;
    
      -- Update Eployee Status
UPDATE b_employees 
SET 
    status = 0
WHERE
    link_user_id = p_user_id;

    -- Set result
    IF ln_c_count = 0 AND ln_p_count = 0 THEN
        SET lv_result = 'done';
    ELSE
        SET lv_result = 'task left';
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_user_child_task_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`lance`@`%` PROCEDURE `update_user_child_task_status`(
    IN p_ct_id INT,
    IN p_status_id INT,
    OUT result VARCHAR(10)
)
BEGIN
    UPDATE rel_user_childtask 
    SET status = p_status_id 
    WHERE id = p_ct_id;

    SET result = 'Done'; -- Correct way to assign OUT parameter
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-08 22:33:22
