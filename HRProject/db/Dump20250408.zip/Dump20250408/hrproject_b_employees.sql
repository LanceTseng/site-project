CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_employees`
--

DROP TABLE IF EXISTS `b_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_employees` (
  `employee_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT 'from object_type.employee_status\n1. onboarding\n2. offboarding\n3. normal\n4. cancelled',
  `address` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `is_active` tinyint DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_updated_date` datetime DEFAULT NULL,
  `link_user_id` int DEFAULT NULL,
  `onboard_date` date DEFAULT NULL,
  `offboard_date` date DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_employees`
--

LOCK TABLES `b_employees` WRITE;
/*!40000 ALTER TABLE `b_employees` DISABLE KEYS */;
INSERT INTO `b_employees` VALUES (2,'ana','hoise',1,0,'99 elm street','7893332222',1,'2025-02-09 00:35:00','2025-02-13 01:20:04',2,NULL,NULL),(3,'Jack','Polm',3,1,'99 elm street','4183392222',1,'2025-02-13 14:34:18','2025-04-05 02:09:49',3,NULL,NULL),(6,'Jane','Smith',2,1,'456 Elm St, Shelbyville','1235897655',1,'2025-02-16 15:05:03','2025-04-05 02:57:34',6,NULL,NULL),(7,'David','Wilson',2,0,'987 Cedar St, Brockway','4167789098',1,'2025-02-16 15:05:29','2025-02-16 15:05:29',7,NULL,NULL),(8,'Grace','Lee',1,0,'864 Cherry St, Capital City','7809654787',1,'2025-02-16 15:05:54','2025-02-16 15:05:54',8,NULL,NULL),(9,'Carol','Davis',3,0,'246 Walnut St, Shelbyville','5559876000',1,'2025-02-16 15:06:19','2025-04-09 01:37:49',9,'2025-04-01',NULL),(10,'Frank','Garcia',3,0,'246 Walnut St, Shelbyville','5557890000',1,'2025-02-16 15:40:39','2025-02-16 15:40:39',10,NULL,NULL),(11,'Jay','Lim',3,2,'334 Elm Street','1231231234',1,'2025-02-16 18:15:05','2025-04-09 01:57:30',11,NULL,NULL),(12,'Ana','Rynette',3,0,'333 King Street','4175840983',1,'2025-02-16 20:06:00','2025-03-20 14:03:06',12,NULL,NULL),(17,'Brige','Wilson',3,3,'33 Elm Street','3334443333',1,'2025-02-26 22:07:17','2025-03-20 04:14:19',17,NULL,NULL),(18,'Ariel','Jackuback',3,3,'21 Dundas West Toronto','6471112233',1,'2025-03-16 20:46:46','2025-03-16 21:11:04',18,NULL,NULL);
/*!40000 ALTER TABLE `b_employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-08 22:33:22
