CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_documents`
--

DROP TABLE IF EXISTS `b_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_documents` (
  `document_id` int NOT NULL AUTO_INCREMENT,
  `document_name` varchar(100) DEFAULT NULL,
  `document_path` varchar(100) DEFAULT NULL,
  `require_upload` tinyint DEFAULT NULL,
  PRIMARY KEY (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_documents`
--

LOCK TABLES `b_documents` WRITE;
/*!40000 ALTER TABLE `b_documents` DISABLE KEYS */;
INSERT INTO `b_documents` VALUES (1,'Welcome Package Guide','WelcomePackageGuide.pdf',1),(2,'New Employee Handbook','NewEmployeeHandbook.pdf',1),(3,'HR Policy Agreement','HRPolicyAgreement.pdf',1),(4,'Employee Benefits Overview','EmployeeBenefitsOverview.pdf',0),(5,'IT Security Guidelines','ITSecurityGuidelines.pdf',0),(6,'Workstation Setup Guide','',0),(7,'Attendance Policy Document','AttendancePolicyDocument.pdf',1),(8,'KPI and Performance Guide','',0),(9,'Training Schedule Overview','',0),(10,'Mentor Program Guide','',0),(15,'I-9 Verification Document','1739766192434-I-9Verification.pdf',1),(16,'Offboarding Document','1740059691354-I-9Verification.pdf',1),(17,'Process Termination Paperwork','1741028676264-ProcessTerminationPaperwork.pdf',1),(18,'Benefits Information','1741028862082-BenefitsInformation.pdf',1),(19,'Knowledge Transfer',NULL,1),(20,'Resume or CV','1742162122101-CV-20250304.docx.pdf',1);
/*!40000 ALTER TABLE `b_documents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-08 22:33:22
