CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_child_tasks`
--

DROP TABLE IF EXISTS `b_child_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_child_tasks` (
  `child_task_id` int NOT NULL AUTO_INCREMENT,
  `parent_task_id` int NOT NULL,
  `child_task_name` varchar(45) DEFAULT NULL,
  `child_task_description` varchar(145) DEFAULT NULL,
  `document_id` int DEFAULT NULL,
  `training_module_id` int DEFAULT NULL COMMENT 'training_department_id(from object_type.training_department)',
  `equipment_type_id` int DEFAULT NULL,
  `access_provisioning_id` int DEFAULT NULL,
  `interview_id` int DEFAULT NULL,
  `survey_id` int DEFAULT NULL,
  `hand_over_id` int DEFAULT NULL,
  `enabled` tinyint DEFAULT '1',
  PRIMARY KEY (`child_task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_child_tasks`
--

LOCK TABLES `b_child_tasks` WRITE;
/*!40000 ALTER TABLE `b_child_tasks` DISABLE KEYS */;
INSERT INTO `b_child_tasks` VALUES (1,1,'Prepare Welcome Package','Create and distribute welcome materials for new employees',NULL,NULL,NULL,NULL,NULL,NULL,0,1),(2,1,'Schedule Welcome Meeting','Organize a meeting for the introduction session',2,NULL,NULL,NULL,NULL,NULL,NULL,1),(3,2,'Verify Employee Documents','Check and validate required HR paperwork',1,NULL,NULL,NULL,NULL,NULL,0,1),(4,2,'Explain Benefits','Discuss employee benefits and insurance plans',18,NULL,NULL,NULL,NULL,NULL,0,1),(5,3,'Set Up Email Account','Create and activate official email for the new hire',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(6,3,'Provide Workstation','Assign and set up computer and necessary tools',NULL,NULL,1,NULL,NULL,NULL,0,1),(7,4,'Conduct Security Briefing','Explain company cybersecurity and safety rules',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(8,4,'Distribute Security Credentials','Provide necessary login credentials and ID badges',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(9,5,'Tour Work Area','Show workstations, meeting rooms, and facilities',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(10,5,'Introduce Key Personnel','Introduce new employees to department heads',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(11,6,'Review Attendance Policy','Explain work hours, leaves, and attendance tracking',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(12,6,'Sign Policy Acknowledgment','Confirm acknowledgment of company policies',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(13,7,'Assign a Mentor','Pair new hires with a mentor for guidance',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(14,7,'Schedule First Mentor Meeting','Set up an initial mentor-mentee session',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(15,8,'Provide Training Materials','Distribute training resources and guides',NULL,4,NULL,NULL,NULL,NULL,NULL,1),(16,8,'Schedule Training Sessions','Organize hands-on training for job-related tasks',NULL,1,NULL,NULL,NULL,NULL,NULL,1),(17,9,'Host Team Lunch','Arrange a casual meet-and-greet with colleagues',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(18,9,'Assign Buddy','Assign a buddy for daily support and guidance',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(19,10,'Explain KPIs','Discuss key performance indicators and expectations',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(31,11,'Assign Eqpt - Monitor','Assign Eqpt',NULL,NULL,3,NULL,NULL,NULL,NULL,1),(32,11,'Assign Eqpt - Laptop','Assign Eqpt - Laptop',NULL,NULL,1,NULL,NULL,NULL,NULL,1),(33,11,'Other Task','Other Task',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(34,11,'disable task test','disable task test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(38,11,'Feedback Collection','Feedback Collection',NULL,NULL,NULL,NULL,NULL,1,NULL,1),(39,11,'Exit Survey','Exit Survey demo',NULL,NULL,NULL,NULL,NULL,2,NULL,1),(40,11,'I-9 Verification','I-9 Verification',15,NULL,NULL,NULL,NULL,NULL,NULL,1),(42,19,'Schedule Exit Interview',NULL,NULL,NULL,NULL,NULL,NULL,3,NULL,1),(43,20,'Revoke System Access','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(44,20,'Revoke Badge Access','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(45,21,'Collect Company Laptop','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(46,21,'Collect Access Badge','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(47,22,'Process Termination Paperwork',NULL,17,NULL,NULL,NULL,NULL,NULL,NULL,1),(48,22,'Provide Benefits Information',NULL,18,NULL,NULL,NULL,NULL,NULL,NULL,1),(49,23,'Arrange Knowledge Transfer','',19,NULL,NULL,NULL,NULL,NULL,1,1),(50,24,'Process Final Paycheck','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(51,24,'Process Benefits Payout','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(52,25,'Conduct Exit Survey',NULL,NULL,NULL,NULL,NULL,NULL,2,NULL,1),(53,8,'IT Training Schedule','IT Training Schedule',NULL,2,NULL,NULL,NULL,NULL,NULL,1),(56,27,'Onboarding Feedback','Onboarding Feedback',NULL,NULL,NULL,NULL,NULL,1,0,1);
/*!40000 ALTER TABLE `b_child_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-08 22:33:22
