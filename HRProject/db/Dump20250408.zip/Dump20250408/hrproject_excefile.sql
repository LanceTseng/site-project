CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `excefile`
--

DROP TABLE IF EXISTS `excefile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `excefile` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `excefile`
--

LOCK TABLES `excefile` WRITE;
/*!40000 ALTER TABLE `excefile` DISABLE KEYS */;
INSERT INTO `excefile` VALUES (64,'Emma Johnson','emma.johnson@example.com'),(65,'Michael Smith','michael.smith@example.com'),(66,'David Brown','david.brown@example.com'),(67,'Sarah Williams','sarah.williams@example.com'),(68,'Jessica Davis','jessica.davis@example.com'),(69,'Amanda Wilson','amanda.wilson@example.com'),(70,'Christopher Miller','christopher.miller@example.com'),(71,'Matthew Taylor','matthew.taylor@example.com'),(72,'Olivia Anderson','olivia.anderson@example.com'),(73,'Daniel Thomas','daniel.thomas@example.com'),(74,'Sophia Martinez','sophia.martinez@example.com'),(75,'Andrew Garcia','andrew.garcia@example.com'),(76,'Elizabeth Rodriguez','elizabeth.rodriguez@example.com'),(77,'James Lee','james.lee@example.com'),(78,'Natalie Hernandez','natalie.hernandez@example.com'),(79,'Robert Young','robert.young@example.com'),(80,'Megan King','megan.king@example.com'),(81,'William Wright','william.wright@example.com'),(82,'Victoria Lopez','victoria.lopez@example.com'),(83,'Kevin Scott','kevin.scott@example.com');
/*!40000 ALTER TABLE `excefile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-08 22:33:21
