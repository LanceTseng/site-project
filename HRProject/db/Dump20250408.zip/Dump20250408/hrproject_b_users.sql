CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_users`
--

DROP TABLE IF EXISTS `b_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) DEFAULT NULL,
  `role_id` int DEFAULT NULL COMMENT 'from object_type.role (the same as department)',
  `is_active` tinyint DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`,`username`),
  UNIQUE KEY `username_UNIQUE` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_users`
--

LOCK TABLES `b_users` WRITE;
/*!40000 ALTER TABLE `b_users` DISABLE KEYS */;
INSERT INTO `b_users` VALUES (2,'ana_hoise','ana_hoise',1,1,'2025-02-09 00:35:00','2025-02-13 01:37:38'),(3,'jack_polm','jack_polm',1,1,'2025-02-13 14:34:17','2025-03-31 04:10:20'),(6,'jane_smith','jane_smith',2,1,'2025-02-16 15:05:03','2025-02-16 15:05:03'),(7,'david_wilson','david_wilson',2,1,'2025-02-16 15:05:29','2025-02-16 15:05:29'),(8,'grace_lee','grace_lee',1,1,'2025-02-16 15:05:54','2025-02-16 15:05:54'),(9,'carol_davis','carol_davis',3,1,'2025-02-16 15:06:19','2025-04-05 16:59:10'),(10,'frank_garcia','frank_garcia',3,1,'2025-02-16 15:40:39','2025-02-16 15:40:39'),(11,'jay_lim','jay_lim',3,1,'2025-02-16 18:15:05','2025-04-09 01:57:30'),(12,'ana_rynette','ana_rynette',3,1,'2025-02-16 20:06:00','2025-02-16 20:06:00'),(17,'brige_wilson','brige_wilson',3,1,'2025-02-26 22:07:17','2025-02-26 22:07:17'),(18,'ariel_jack','ariel_jack',3,1,'2025-03-16 20:46:45','2025-03-16 20:46:45');
/*!40000 ALTER TABLE `b_users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-08 22:33:21
