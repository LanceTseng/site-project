CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_form_design`
--

DROP TABLE IF EXISTS `b_form_design`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_form_design` (
  `form_id` int DEFAULT NULL,
  `form_name` varchar(100) DEFAULT NULL,
  `form_type_id` int DEFAULT NULL COMMENT 'form_type',
  `form_question_type_id` int DEFAULT NULL COMMENT 'form_ques_type',
  `form_question_id` int NOT NULL AUTO_INCREMENT,
  `form_question_display` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`form_question_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_form_design`
--

LOCK TABLES `b_form_design` WRITE;
/*!40000 ALTER TABLE `b_form_design` DISABLE KEYS */;
INSERT INTO `b_form_design` VALUES (1,'Feedback Survey',1,1,1,'How satisfied are you with our service? (1 = Very Dissatisfied, 5 = Very Satisfied)'),(1,'Feedback Survey',1,1,2,'How easy was it to use our platform? (1 = Very Difficult, 5 = Very Easy)'),(1,'Feedback Survey',1,1,3,'How likely are you to recommend us to others? (1 = Not Likely, 5 = Very Likely)'),(1,'Feedback Survey',1,1,4,'How responsive was our customer support? (1 = Not Responsive, 5 = Very Responsive)'),(1,'Feedback Survey',1,1,5,'How would you rate the overall value for money? (1 = Poor, 5 = Excellent)'),(1,'Feedback Survey',1,2,6,'Any additional comments or suggestions?'),(2,'Exit Survey',2,1,7,'How satisfied were you with your overall experience at the company? (1 = Very Dissatisfied, 5 = Very Satisfied)'),(2,'Exit Survey',2,1,8,'How would you rate the work environment and company culture? (1 = Poor, 5 = Excellent)'),(2,'Exit Survey',2,1,9,'How satisfied were you with the career growth opportunities? (1 = No Growth, 5 = Excellent Growth)'),(2,'Exit Survey',2,1,10,'How well did management support you in your role? (1 = Not Supportive, 5 = Very Supportive)'),(2,'Exit Survey',2,1,11,'How likely are you to recommend this company to others? (1 = Not Likely, 5 = Very Likely)'),(3,'Exit Interview',2,1,12,'Reason for Leaving(1 - Better Opportunity, 2 - Work-Life Balance, 3 - Compensation, 4 - Personal Reasons, 5 - Other)'),(3,'Exit Interview',2,2,13,'Do you feel your manager gave you what you needed to succeed? '),(3,'Exit Interview',2,2,14,'Is there anything that would have changed your mind about leaving?');
/*!40000 ALTER TABLE `b_form_design` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 12:19:10
