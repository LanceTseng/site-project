CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `rel_user_form`
--

DROP TABLE IF EXISTS `rel_user_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rel_user_form` (
  `id` int NOT NULL AUTO_INCREMENT,
  `form_id` int DEFAULT NULL,
  `user_childtask_id` varchar(45) DEFAULT NULL COMMENT 'rel_user_childtask.id',
  `form_question_id` int DEFAULT NULL,
  `form_question_response` varchar(145) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rel_user_form`
--

LOCK TABLES `rel_user_form` WRITE;
/*!40000 ALTER TABLE `rel_user_form` DISABLE KEYS */;
INSERT INTO `rel_user_form` VALUES (51,1,'1177',1,'4','2025-04-09 01:48:06','2025-04-09 01:48:06'),(52,1,'1177',2,'3','2025-04-09 01:48:06','2025-04-09 01:48:06'),(53,1,'1177',3,'3','2025-04-09 01:48:06','2025-04-09 01:48:06'),(54,1,'1177',4,'3','2025-04-09 01:48:06','2025-04-09 01:48:06'),(55,1,'1177',5,'2','2025-04-09 01:48:06','2025-04-09 01:48:06'),(56,1,'1177',6,'good process','2025-04-09 01:48:06','2025-04-09 01:48:06'),(57,2,'958',7,'5','2025-04-09 01:58:39','2025-04-09 01:58:39'),(58,2,'958',8,'4','2025-04-09 01:58:39','2025-04-09 01:58:39'),(59,2,'958',9,'3','2025-04-09 01:58:39','2025-04-09 01:58:39'),(60,2,'958',10,'4','2025-04-09 01:58:39','2025-04-09 01:58:39'),(61,2,'958',11,'1','2025-04-09 01:58:39','2025-04-09 01:58:39'),(62,3,'950',12,'5','2025-04-09 02:01:05','2025-04-09 02:01:05'),(63,3,'950',13,'good to learning from the manager','2025-04-09 02:01:05','2025-04-09 02:01:05'),(64,3,'950',14,'start another object','2025-04-09 02:01:05','2025-04-09 02:01:05');
/*!40000 ALTER TABLE `rel_user_form` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 12:19:09
