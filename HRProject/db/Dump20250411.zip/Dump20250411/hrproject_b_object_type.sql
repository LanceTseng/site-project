CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_object_type`
--

DROP TABLE IF EXISTS `b_object_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_object_type` (
  `object_id` int NOT NULL AUTO_INCREMENT,
  `object_type_name` varchar(45) NOT NULL,
  `object_type_item_key` int NOT NULL,
  `object_type_item_value` varchar(45) DEFAULT NULL,
  `object_sequence` float DEFAULT NULL,
  PRIMARY KEY (`object_id`,`object_type_name`,`object_type_item_key`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_object_type`
--

LOCK TABLES `b_object_type` WRITE;
/*!40000 ALTER TABLE `b_object_type` DISABLE KEYS */;
INSERT INTO `b_object_type` VALUES (1,'employee_status',1,'onboarding',2.1),(2,'employee_status',2,'offboarding',2.2),(3,'employee_status',3,'normal',3),(4,'employee_status',9,'cancelled',4),(5,'employee_status',0,'pending',1),(9,'access_role',1,'Admin',NULL),(10,'access_role',2,'IT',NULL),(11,'access_role',3,'Employee',NULL),(12,'department',1,'HR',NULL),(13,'department',2,'IT',NULL),(14,'department',3,'Employee',NULL),(15,'equipment_type',1,'Laptop',NULL),(16,'equipment_type',2,'Desktop',NULL),(17,'equipment_type',3,'Monitor',NULL),(18,'equipment_type',4,'Others',NULL),(19,'trainning_department',1,'HR',NULL),(20,'trainning_department',2,'IT',NULL),(21,'trainning_department',3,'EMPLOYEE',NULL),(22,'user_role',1,'HR',NULL),(23,'user_role',2,'IT',NULL),(24,'user_role',3,'EMPLOYEE',NULL),(25,'task_group',1,'Onboard',NULL),(26,'task_group',2,'Offboard',NULL),(27,'user_child_taks_status',0,'pending',NULL),(28,'user_child_taks_status',1,'processing',NULL),(29,'user_child_taks_status',2,'completed',NULL),(30,'user_child_taks_status',9,'cancelled',NULL),(31,'user_parent_taks_status',0,'pending',NULL),(32,'user_parent_taks_status',1,'processing',NULL),(33,'user_parent_taks_status',2,'completed',NULL),(34,'user_parent_taks_status',9,'cancelled',NULL),(35,'form_type',1,'onboard',1),(36,'form_type',2,'offboard',2),(38,'form_ques_type',1,'1-5',1),(39,'form_ques_type',2,'short-answer',2),(40,'form_ques_type',3,'yes-no',3),(41,'access_type',1,'feature',1),(42,'access_type',2,'menu',2),(43,'ticket_status',1,'new',NULL),(44,'ticket_status',2,'processing',NULL),(45,'ticket_status',3,'completed',NULL),(46,'ticket_status',4,'cancelled',NULL),(47,'ticket_status',5,'reject',NULL),(48,'access_type',3,'access',3),(49,'payment_type',1,'hoursly',NULL),(50,'payment_type',2,'bi-weekly',NULL),(51,'payment_type',3,'semi-monthly',NULL),(52,'payment_type',4,'monthly',NULL),(53,'training_department',1,'HR',NULL),(54,'training_department',2,'IT',NULL),(55,'training_department',3,'EMPLOYEE',NULL),(56,'training_department',4,'ALL',NULL),(57,'training_status',1,'pending',NULL),(58,'training_status',2,'processing',NULL),(59,'training_status',3,'completed',NULL),(60,'training_status',4,'verifying',NULL);
/*!40000 ALTER TABLE `b_object_type` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 12:19:09
