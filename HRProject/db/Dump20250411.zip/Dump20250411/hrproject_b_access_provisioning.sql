CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_access_provisioning`
--

DROP TABLE IF EXISTS `b_access_provisioning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_access_provisioning` (
  `access_id` int NOT NULL AUTO_INCREMENT,
  `access_name` varchar(45) DEFAULT NULL,
  `access_type_id` int DEFAULT NULL COMMENT 'object_type.access_type',
  `access_description` varchar(145) DEFAULT NULL,
  `access_role_id` int DEFAULT NULL COMMENT 'form object_type.user_role',
  `enabled` tinyint DEFAULT NULL,
  PRIMARY KEY (`access_id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_access_provisioning`
--

LOCK TABLES `b_access_provisioning` WRITE;
/*!40000 ALTER TABLE `b_access_provisioning` DISABLE KEYS */;
INSERT INTO `b_access_provisioning` VALUES (2,'Equipment',1,'Handles equipment management and maintenance records.',NULL,0),(3,'Profile',1,'Profile',NULL,1),(4,'Document',1,'Handles document storage, retrieval, and management.',NULL,1),(5,'Survey',1,'Manages employee and customer feedback surveys.',NULL,1),(6,'Training',1,'Provides training materials and progress tracking.',NULL,1),(7,'Goals',1,'Tracks and manages employee performance goals.',NULL,1),(10,'HRIS Management',1,'Manages employee details, roles, and access permissions.',NULL,1),(15,'User Task',1,'Manages user task assignments and tracking.',NULL,1),(22,'Employee Dashboard',2,'Dashboard Menu',NULL,1),(25,'IT Dashboard',2,'Dashboard Menu',NULL,1),(28,'HR Dashboard',2,'Dashboard Menu',NULL,1),(31,'Report',2,'Report Menu',NULL,1),(34,'Mainenance',2,'Mainenance Menu',NULL,1),(38,'Task Management',1,NULL,NULL,1),(41,'Equipment Management',1,NULL,NULL,1),(47,'Document Management',1,NULL,NULL,1),(52,'Training Management',1,NULL,NULL,1),(53,'Access Provisioning Management',1,NULL,NULL,1),(56,'User Access Management',1,'User Access Management',NULL,1),(57,'Ticket Request',1,'Ticket Request',NULL,1),(63,'Payment',1,'Payment',NULL,1),(66,'Training Full Access',3,'Training Full Access',NULL,1),(67,'Total Access',1,'Total',NULL,1),(68,'Ticket Full Access',3,'query all ticket',NULL,1),(69,'User Task Access All',3,'User Task Access All',NULL,1);
/*!40000 ALTER TABLE `b_access_provisioning` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 12:19:09
