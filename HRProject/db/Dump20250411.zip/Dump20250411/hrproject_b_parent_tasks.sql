CREATE DATABASE  IF NOT EXISTS `hrproject` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hrproject`;
-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hrproject
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `b_parent_tasks`
--

DROP TABLE IF EXISTS `b_parent_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `b_parent_tasks` (
  `task_id` int NOT NULL AUTO_INCREMENT,
  `task_name` varchar(45) DEFAULT NULL,
  `task_description` varchar(45) DEFAULT NULL,
  `task_group_id` int DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_updated_date` datetime DEFAULT NULL,
  `enabled` tinyint DEFAULT '1',
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `b_parent_tasks`
--

LOCK TABLES `b_parent_tasks` WRITE;
/*!40000 ALTER TABLE `b_parent_tasks` DISABLE KEYS */;
INSERT INTO `b_parent_tasks` VALUES (2,'HR Documentation','Complete employee paperwork and contracts',1,'2024-02-01 08:30:00','2024-02-01 08:30:00',1),(3,'IT System Setup','Setup email, accounts, and work devices',1,'2024-02-01 09:00:00','2024-02-01 09:00:00',1),(4,'Security Training','Learn about cybersecurity policies',1,'2024-02-01 09:30:00','2024-02-01 09:30:00',1),(5,'Office Tour','Introduction to office facilities and teams',1,'2024-02-01 10:00:00','2025-03-03 23:49:51',1),(6,'Company Policies Overview','Review workplace rules and regulations',1,'2024-02-01 10:30:00','2024-02-01 10:30:00',1),(7,'Mentorship Assignment','Assign a mentor to guide the new employee',1,'2024-02-01 11:00:00','2024-02-01 11:00:00',1),(8,'Job Role Training','Training on job-specific tasks and tools',1,'2024-02-01 11:30:00','2024-02-01 11:30:00',1),(9,'Team Introduction','Meet and interact with colleagues',1,'2024-02-01 12:00:00','2024-02-01 12:00:00',1),(10,'Performance Expectations','Understand key performance indicators',1,'2024-02-01 12:30:00','2024-02-01 12:30:00',1),(19,'Exit Interviews','',2,'2025-03-03 13:32:10','2025-03-03 18:32:46',1),(20,'Access Revocation','',2,'2025-03-03 13:32:10','2025-03-03 18:32:54',1),(21,'Asset Return','',2,'2025-03-03 13:32:10','2025-03-03 13:32:10',1),(22,'Offboarding Documentation','',2,'2025-03-03 13:32:10','2025-03-03 13:32:10',1),(23,'Knowledge Transfer','',2,'2025-03-03 13:32:10','2025-03-03 13:32:10',1),(24,'Final Payments','',2,'2025-03-03 13:32:10','2025-03-03 13:32:10',1),(25,'Exit Surveys','',2,'2025-03-03 13:32:10','2025-03-03 13:32:10',1),(27,'Feedback Collection','Feedback Collection',1,'2025-04-09 01:36:13','2025-04-09 01:36:13',1);
/*!40000 ALTER TABLE `b_parent_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-11 12:19:10
